char 	*Prompt, 		/* prompt string 	*/
	*MyHome;		/* Home dir      	*/

char 	**Path;			/* Path for Dir search  */

extern char **environ;

#include <stdio.h>


/*
 *  Declare all functions called from nut.y here, and
 *  then implement them in support.c.
 */

extern char *getsb(char *sb);
